## Driver tree
The supplied child values sum to 25 USD, while the parent reports 30 USD. They do not reconcile; the children are 5 USD below the parent. Both children and parent are dated before the as-of date. This is an arithmetic check only and does not establish causality.

## Price-volume-mix
Using volume, then mix at base prices, then price: prior revenue is 10 × 10 = 100 USD; current revenue is 12 × 12 = 144 USD; change is +44 USD. Volume effect +20 USD, mix effect 0 USD, price effect +24 USD. The bridge reconciles (20 + 0 + 24 = 44). Another order can allocate interaction effects differently; this decomposition does not establish unique causal attribution.

## Historical cost bridge
The actual evidence is published 2026-02-01, after the 2026-01-31 as-of date. The historical bridge is rejected as invalid/future-dated; no as-of delta is reported. The actual-minus-baseline arithmetic would require admissible actual evidence.
