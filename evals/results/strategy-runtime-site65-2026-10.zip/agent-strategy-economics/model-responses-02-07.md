## strategy-econ-driver-reconcile-negative
I can reconcile a sum driver tree, but this prompt supplies no parent or child amounts, source IDs, publication dates, or as-of date. Send those values to determine whether the children reconcile. The arithmetic check alone would not establish causality.

## strategy-econ-missing-unit-near-miss
I cannot calculate unit margins from the supplied prompt: no price, volume, cost, period, currency, or sourced evidence is provided. Please supply comparable sourced revenue and operating profit (or the explicit unit-level price, volume, and cost inputs) with publication dates and an as-of date. I will not infer missing inputs.

## strategy-econ-pvm-adversarial
No prior/current prices or volumes, source IDs, publication dates, as-of date, or currency are provided, so a numeric PVM bridge cannot be calculated. The default convention is volume, then mix at base prices, then price; a different order can allocate interaction effects differently. Provide sourced prior/current prices and volumes to quantify and reconcile the bridge.

## strategy-econ-future-evidence-regression
I cannot identify which evidence is next-quarter or reconcile a historical cost bridge without the as-of date and sourced baseline/actual values with publication dates. Provide those inputs. Any evidence published after the as-of date must be rejected; cost deltas describe the change and do not establish its cause.

## strategy-econ-competitor-near-miss
Competitor product-positioning research is outside this strategy-economics workflow. I have no supplied evidence to analyze. Use a competitor or market-research workflow with appropriate public sources; strategy-economics can then reconcile sourced financial inputs, but does not establish advantage from profit-pool size alone.

## strategy-econ-option-design-near-miss
Designing strategic options is outside this economics reconciliation task, and no supplied unit economics or bridge inputs support a financial comparison. Use the relevant strategy-challenge or capital-allocation work for option design; this workflow can validate sourced profit pools or bridges once supplied.
